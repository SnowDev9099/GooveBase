﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using NAudio.Wave;
using LibVLCSharp.Shared;
using LibVLCSharp.WinForms;

namespace GooveBase
{
    public class MainForm : Form
    {
        private ListBox listBoxSongs;
        private Button buttonPlay;
        private Button buttonPause;
        private Button buttonStop;
        private Button buttonSettings;
        private Label titleLabel;
        private TextBox textBoxVolume;
        private TrackBar trackBarSongPosition;
        private Timer fadeTimer;
        private Timer trackTimer;
        private float fadeVolume = 0.0f;

        private CheckBox checkBoxFullScreen;
        private Button buttonApplySettings;
        private Button buttonRevertSettings;

        private string musicDirectory;
        private IWavePlayer wavePlayer;
        private AudioFileReader audioFile;
        private MediaPlayer mediaPlayer;
        private VideoView videoView;
        private bool isVideoPlaying = false;

        private float currentVolume = 0.5f;
        private bool isFullScreen = false;
        private bool isFadingIn = false;

        public MainForm()
        {
            InitializeComponent();
            CreateMusicDirectory();
            LoadSongs();
            InitializeFadeTimer();
            InitializeTrackTimer();

            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string iconPath = Path.Combine(appDataPath, "GooveBase", "Data", "icon.ico");

            if (File.Exists(iconPath))
            {
                this.Icon = new Icon(iconPath);
            }

            Core.Initialize(); // Initialize LibVLC
        }

        private void InitializeComponent()
        {
            this.Text = "GooveBase";
            this.Size = new Size(800, 600);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            titleLabel = new Label
            {
                Text = "GooveBase",
                Font = new Font("Segoe UI", 28, FontStyle.Bold),
                ForeColor = Color.FromArgb(220, 220, 220),
                Dock = DockStyle.Top,
                TextAlign = ContentAlignment.MiddleCenter,
                AutoSize = false,
                Height = 80,
                Padding = new Padding(0, 10, 0, 10),
                BackColor = Color.FromArgb(50, 50, 50)
            };
            this.Controls.Add(titleLabel);

            listBoxSongs = new ListBox
            {
                Font = new Font("Segoe UI", 14),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.None,
                Location = new Point(50, 100),
                Size = new Size(700, 300)
            };
            listBoxSongs.SelectedIndexChanged += ListBoxSongs_SelectedIndexChanged;
            this.Controls.Add(listBoxSongs);

            buttonPlay = CreateCircularButton("Play", Color.Green, new Point(150, 420));
            buttonPlay.Click += ButtonPlay_Click;
            this.Controls.Add(buttonPlay);

            buttonPause = CreateCircularButton("Pause", Color.Orange, new Point(250, 420));
            buttonPause.Click += ButtonPause_Click;
            this.Controls.Add(buttonPause);

            buttonStop = CreateCircularButton("Stop", Color.Red, new Point(350, 420));
            buttonStop.Click += ButtonStop_Click;
            this.Controls.Add(buttonStop);

            textBoxVolume = new TextBox
            {
                Text = (currentVolume * 100).ToString(),
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.None,
                Location = new Point(50, 500),
                Width = 100,
                TextAlign = HorizontalAlignment.Center
            };
            textBoxVolume.TextChanged += TextBoxVolume_TextChanged;
            this.Controls.Add(textBoxVolume);

            trackBarSongPosition = new TrackBar
            {
                Minimum = 0,
                Maximum = 100,
                Value = 0,
                TickStyle = TickStyle.None,
                LargeChange = 10,
                SmallChange = 1,
                Orientation = Orientation.Horizontal,
                Location = new Point(200, 500),
                Size = new Size(550, 45),
                BackColor = Color.FromArgb(30, 30, 30),
                ForeColor = Color.White
            };
            trackBarSongPosition.Scroll += TrackBarSongPosition_Scroll;
            this.Controls.Add(trackBarSongPosition);

            videoView = new VideoView
            {
                Dock = DockStyle.Fill,
                Visible = false
            };
            this.Controls.Add(videoView);

            checkBoxFullScreen = new CheckBox
            {
                Text = "Fullscreen",
                ForeColor = Color.White,
                BackColor = Color.FromArgb(30, 30, 30),
                Font = new Font("Segoe UI", 12),
                AutoSize = true,
                Location = new Point(20, 20)
            };

            buttonApplySettings = new Button
            {
                Text = "Apply Settings",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(50, 150, 250),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Size = new Size(150, 40),
                Location = new Point(20, 70)
            };
            buttonApplySettings.Click += ButtonApplySettings_Click;

            buttonRevertSettings = new Button
            {
                Text = "Revert Settings",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(200, 50, 50),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Size = new Size(150, 40),
                Location = new Point(180, 70)
            };
            buttonRevertSettings.Click += ButtonRevertSettings_Click;

            Panel settingsPanel = new Panel
            {
                BackColor = Color.FromArgb(30, 30, 30),
                Size = new Size(350, 150),
                Location = new Point((this.Width - 350) / 2, (this.Height - 150) / 2),
                Visible = false
            };
            settingsPanel.Controls.Add(checkBoxFullScreen);
            settingsPanel.Controls.Add(buttonApplySettings);
            settingsPanel.Controls.Add(buttonRevertSettings);
            this.Controls.Add(settingsPanel);
        }

        private Button CreateCircularButton(string text, Color buttonColor, Point location)
        {
            Button button = new Button
            {
                Text = text,
                ForeColor = Color.White,
                BackColor = buttonColor,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Size = new Size(60, 60),
                Location = location
            };

            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(new Rectangle(0, 0, button.Width, button.Height));
            button.Region = new Region(path);

            return button;
        }

        private void CreateMusicDirectory()
        {
            string baseDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GooveBaseData");
            musicDirectory = Path.Combine(baseDirectory, "Songs");
            if (!Directory.Exists(musicDirectory))
            {
                Directory.CreateDirectory(musicDirectory);
            }

            string dataDirectory = Path.Combine(baseDirectory, "Data");
            if (!Directory.Exists(dataDirectory))
            {
                Directory.CreateDirectory(dataDirectory);
            }
        }

        private void LoadSongs()
        {
            if (Directory.Exists(musicDirectory))
            {
                var files = Directory.GetFiles(musicDirectory)
                    .Where(f => new[] { ".mp3", ".wav", ".flac", ".ogg", ".aac", ".m4a", ".mp4", ".avi", ".mkv", ".mov" }
                    .Contains(Path.GetExtension(f).ToLower()))
                    .ToArray();

                listBoxSongs.Items.AddRange(files.Select(Path.GetFileName).ToArray());
            }
            else
            {
                MessageBox.Show("Music directory not found!");
            }
        }

        private void ListBoxSongs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxSongs.SelectedItem != null)
            {
                string selectedSong = listBoxSongs.SelectedItem.ToString();
                string songPath = Path.Combine(musicDirectory, selectedSong);
                PlayMedia(songPath);
            }
        }

        private void PlayMedia(string path)
        {
            StopMedia(); // Stop any currently playing media

            string extension = Path.GetExtension(path).ToLower();

            if (extension == ".mp4" || extension == ".avi" || extension == ".mkv" || extension == ".mov")
            {
                isVideoPlaying = true;
                videoView.Visible = true;
                titleLabel.Visible = false;

                var libVLC = new LibVLC();
                mediaPlayer = new MediaPlayer(libVLC);
                videoView.MediaPlayer = mediaPlayer;

                Media media = new Media(libVLC, new Uri(path));
                mediaPlayer.Play(media);
            }
            else
            {
                isVideoPlaying = false;
                videoView.Visible = false;
                titleLabel.Visible = true;

                wavePlayer = new WaveOutEvent();
                audioFile = new AudioFileReader(path);
                wavePlayer.Init(audioFile);
                wavePlayer.Play();

                trackTimer.Start();
            }
        }

        private void StopMedia()
        {
            if (wavePlayer != null)
            {
                wavePlayer.Stop();
                wavePlayer.Dispose();
                wavePlayer = null;
                audioFile.Dispose();
                audioFile = null;
            }

            if (mediaPlayer != null)
            {
                mediaPlayer.Stop();
                mediaPlayer.Dispose();
                mediaPlayer = null;
                videoView.Visible = false;
                isVideoPlaying = false;
            }

            trackTimer.Stop();
        }

        private void ButtonPlay_Click(object sender, EventArgs e)
        {
            if (wavePlayer != null)
            {
                wavePlayer.Play();
            }

            if (mediaPlayer != null && isVideoPlaying)
            {
                mediaPlayer.Play();
            }
        }

        private void ButtonPause_Click(object sender, EventArgs e)
        {
            if (wavePlayer != null)
            {
                wavePlayer.Pause();
            }

            if (mediaPlayer != null && isVideoPlaying)
            {
                mediaPlayer.Pause();
            }
        }

        private void ButtonStop_Click(object sender, EventArgs e)
        {
            StopMedia();
        }

        private void InitializeFadeTimer()
        {
            fadeTimer = new Timer();
            fadeTimer.Interval = 100;
            fadeTimer.Tick += FadeTimer_Tick;
        }

        private void FadeTimer_Tick(object sender, EventArgs e)
        {
            if (isFadingIn)
            {
                fadeVolume += 0.1f;
                if (fadeVolume >= currentVolume)
                {
                    fadeVolume = currentVolume;
                    fadeTimer.Stop();
                }
            }
            else
            {
                fadeVolume -= 0.1f;
                if (fadeVolume <= 0.0f)
                {
                    fadeVolume = 0.0f;
                    fadeTimer.Stop();
                    StopMedia();
                }
            }

            if (audioFile != null)
            {
                wavePlayer.Volume = fadeVolume;
            }
            else if (mediaPlayer != null && isVideoPlaying)
            {
                mediaPlayer.Volume = (int)(fadeVolume * 100);
            }
        }

        private void InitializeTrackTimer()
        {
            trackTimer = new Timer();
            trackTimer.Interval = 1000; // Update every second
            trackTimer.Tick += TrackTimer_Tick;
        }

        private void TrackTimer_Tick(object sender, EventArgs e)
        {
            if (audioFile != null)
            {
                trackBarSongPosition.Value = (int)((audioFile.CurrentTime.TotalSeconds / audioFile.TotalTime.TotalSeconds) * 100);
            }
            else if (mediaPlayer != null && isVideoPlaying)
            {
                trackBarSongPosition.Value = (int)((mediaPlayer.Time / (double)mediaPlayer.Length) * 100);
            }
        }

        private void TrackBarSongPosition_Scroll(object sender, EventArgs e)
        {
            if (audioFile != null)
            {
                audioFile.CurrentTime = TimeSpan.FromSeconds((trackBarSongPosition.Value / 100.0) * audioFile.TotalTime.TotalSeconds);
            }
            else if (mediaPlayer != null && isVideoPlaying)
            {
                mediaPlayer.Time = (long)((trackBarSongPosition.Value / 100.0) * mediaPlayer.Length);
            }
        }

        private void TextBoxVolume_TextChanged(object sender, EventArgs e)
        {
            if (float.TryParse(textBoxVolume.Text, out float volume))
            {
                currentVolume = Math.Max(0, Math.Min(1, volume / 100));

                if (audioFile != null)
                {
                    wavePlayer.Volume = currentVolume;
                }
                else if (mediaPlayer != null && isVideoPlaying)
                {
                    mediaPlayer.Volume = (int)(currentVolume * 100);
                }
            }
        }

        private void ButtonSettings_Click(object sender, EventArgs e)
        {
            // Show or hide the settings panel
        }

        private void ButtonApplySettings_Click(object sender, EventArgs e)
        {
            // Apply the settings such as fullscreen mode
            isFullScreen = checkBoxFullScreen.Checked;
            this.WindowState = isFullScreen ? FormWindowState.Maximized : FormWindowState.Normal;
        }

        private void ButtonRevertSettings_Click(object sender, EventArgs e)
        {
            // Revert settings to previous values
            checkBoxFullScreen.Checked = isFullScreen;
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
