﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using NAudio.Wave;

namespace GooveBase
{
    public class MainForm : Form
    {
        private ListBox listBoxSongs;
        private Button buttonPlay;
        private Button buttonPause;
        private Button buttonStop;
        private Button buttonSettings;
        private Label titleLabel;
        private TextBox textBoxVolume;
        private TrackBar trackBarSongPosition;
        private Timer fadeTimer;
        private float fadeVolume = 0.0f;

        private CheckBox checkBoxFullScreen;
        private Button buttonApplySettings;
        private Button buttonRevertSettings;

        private string musicDirectory;
        private IWavePlayer wavePlayer;
        private AudioFileReader audioFile;
        private float currentVolume = 0.5f;

        private bool isFullScreen = false;
        private bool isFadingIn = false;

        public MainForm()
        {
            InitializeComponent();
            CreateMusicDirectory();
            LoadSongs();
            InitializeFadeTimer();

            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string iconPath = Path.Combine(appDataPath, "GooveBase", "Data", "icon.ico");

            if (File.Exists(iconPath))
            {
                this.Icon = new Icon(iconPath);
            }
        }

        private void InitializeComponent()
        {
            this.Text = "GooveBase";
            this.Size = new Size(800, 600);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.FormBorderStyle = FormBorderStyle.Sizable;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            titleLabel = new Label
            {
                Text = "GooveBase",
                Font = new Font("Segoe UI", 28, FontStyle.Bold),
                ForeColor = Color.FromArgb(220, 220, 220),
                Dock = DockStyle.Top,
                TextAlign = ContentAlignment.MiddleCenter,
                AutoSize = false,
                Height = 80,
                Padding = new Padding(0, 10, 0, 10),
                BackColor = Color.FromArgb(50, 50, 50)
            };
            this.Controls.Add(titleLabel);

            listBoxSongs = new ListBox
            {
                Font = new Font("Segoe UI", 14),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.None,
                Location = new Point(50, 100),
                Size = new Size(700, 300)
            };
            listBoxSongs.SelectedIndexChanged += ListBoxSongs_SelectedIndexChanged;
            this.Controls.Add(listBoxSongs);

            buttonPlay = CreateCircularButton("Play", Color.Green, new Point(150, 420));
            buttonPlay.Click += ButtonPlay_Click;
            this.Controls.Add(buttonPlay);

            buttonPause = CreateCircularButton("Pause", Color.Orange, new Point(250, 420));
            buttonPause.Click += ButtonPause_Click;
            this.Controls.Add(buttonPause);

            buttonStop = CreateCircularButton("Stop", Color.Red, new Point(350, 420));
            buttonStop.Click += ButtonStop_Click;
            this.Controls.Add(buttonStop);

            textBoxVolume = new TextBox
            {
                Text = (currentVolume * 100).ToString(),
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(40, 40, 40),
                BorderStyle = BorderStyle.None,
                Location = new Point(50, 500),
                Width = 100,
                TextAlign = HorizontalAlignment.Center
            };
            textBoxVolume.TextChanged += TextBoxVolume_TextChanged;
            this.Controls.Add(textBoxVolume);

            trackBarSongPosition = new TrackBar
            {
                Minimum = 0,
                Maximum = 100,
                Value = 0,
                TickStyle = TickStyle.None,
                LargeChange = 10,
                SmallChange = 1,
                Orientation = Orientation.Horizontal,
                Location = new Point(200, 500),
                Size = new Size(550, 45),
                BackColor = Color.FromArgb(30, 30, 30),
                ForeColor = Color.White
            };
            trackBarSongPosition.Scroll += TrackBarSongPosition_Scroll;
            this.Controls.Add(trackBarSongPosition);

            buttonSettings = new Button
            {
                Text = "Settings",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(40, 40, 40),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Size = new Size(120, 40),
                Location = new Point(this.Width - 140, this.Height - 60),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            buttonSettings.Click += ButtonSettings_Click;
            this.Controls.Add(buttonSettings);

            checkBoxFullScreen = new CheckBox
            {
                Text = "Fullscreen",
                ForeColor = Color.White,
                BackColor = Color.FromArgb(30, 30, 30),
                Font = new Font("Segoe UI", 12),
                AutoSize = true,
                Location = new Point(20, 20)
            };

            buttonApplySettings = new Button
            {
                Text = "Apply Settings",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(50, 150, 250),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Size = new Size(150, 40),
                Location = new Point(20, 70)
            };
            buttonApplySettings.Click += ButtonApplySettings_Click;

            buttonRevertSettings = new Button
            {
                Text = "Revert Settings",
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(200, 50, 50),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Size = new Size(150, 40),
                Location = new Point(180, 70)
            };
            buttonRevertSettings.Click += ButtonRevertSettings_Click;

            Panel settingsPanel = new Panel
            {
                BackColor = Color.FromArgb(30, 30, 30),
                Size = new Size(350, 150),
                Location = new Point((this.Width - 350) / 2, (this.Height - 150) / 2),
                Visible = false
            };
            settingsPanel.Controls.Add(checkBoxFullScreen);
            settingsPanel.Controls.Add(buttonApplySettings);
            settingsPanel.Controls.Add(buttonRevertSettings);
            this.Controls.Add(settingsPanel);
        }

        private Button CreateCircularButton(string text, Color buttonColor, Point location)
        {
            Button button = new Button
            {
                Text = text,
                ForeColor = Color.White,
                BackColor = buttonColor,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Size = new Size(60, 60),
                Location = location
            };

            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(new Rectangle(0, 0, button.Width, button.Height));
            button.Region = new Region(path);

            return button;
        }

        private void CreateMusicDirectory()
        {
            string baseDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "GooveBaseData");
            musicDirectory = Path.Combine(baseDirectory, "Songs");
            if (!Directory.Exists(musicDirectory))
            {
                Directory.CreateDirectory(musicDirectory);
            }

            string dataDirectory = Path.Combine(baseDirectory, "Data");
            if (!Directory.Exists(dataDirectory))
            {
                Directory.CreateDirectory(dataDirectory);
            }
        }

        private void LoadSongs()
        {
            if (Directory.Exists(musicDirectory))
            {
                var files = Directory.GetFiles(musicDirectory)
                    .Where(f => new[] { ".mp3", ".wav", ".flac", ".ogg", ".aac", ".m4a" }
                    .Contains(Path.GetExtension(f).ToLower()))
                    .ToArray();

                listBoxSongs.Items.AddRange(files.Select(Path.GetFileName).ToArray());
            }
            else
            {
                MessageBox.Show("Music directory not found!");
            }
        }

        private void ListBoxSongs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxSongs.SelectedItem != null)
            {
                string selectedSong = listBoxSongs.SelectedItem.ToString();
                string songPath = Path.Combine(musicDirectory, selectedSong);
                PlaySong(songPath);
            }
        }

        private void PlaySong(string filePath)
        {
            try
            {
                wavePlayer?.Stop();
                audioFile?.Dispose();
                wavePlayer = new WaveOutEvent();
                audioFile = new AudioFileReader(filePath);

                wavePlayer.Volume = currentVolume;
                textBoxVolume.Text = (currentVolume * 100).ToString();

                wavePlayer.Init(audioFile);
                wavePlayer.Play();

                trackBarSongPosition.Maximum = (int)audioFile.TotalTime.TotalSeconds;
                trackBarSongPosition.Value = 0;

                isFadingIn = true;
                fadeVolume = 0.0f;
                fadeTimer.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error playing song: {ex.Message}");
            }
        }

        private void StopSong()
        {
            fadeTimer.Stop();
            if (wavePlayer != null)
            {
                wavePlayer.Stop();
                wavePlayer.Dispose();
                wavePlayer = null;
            }
            if (audioFile != null)
            {
                audioFile.Dispose();
                audioFile = null;
            }
        }

        private void PauseSong()
        {
            if (wavePlayer != null)
            {
                wavePlayer.Pause();
            }
        }

        private void ResumeSong()
        {
            if (wavePlayer != null)
            {
                wavePlayer.Play();
            }
        }

        private void TextBoxVolume_TextChanged(object sender, EventArgs e)
        {
            if (float.TryParse(textBoxVolume.Text, out float volume))
            {
                currentVolume = Math.Max(0.0f, Math.Min(1.0f, volume / 100.0f));
                if (wavePlayer != null)
                {
                    wavePlayer.Volume = currentVolume;
                }
            }
        }

        private void TrackBarSongPosition_Scroll(object sender, EventArgs e)
        {
            if (audioFile != null)
            {
                audioFile.CurrentTime = TimeSpan.FromSeconds(trackBarSongPosition.Value);
            }
        }

        private void InitializeFadeTimer()
        {
            fadeTimer = new Timer();
            fadeTimer.Interval = 100;
            fadeTimer.Tick += FadeTimer_Tick;
        }

        private void FadeTimer_Tick(object sender, EventArgs e)
        {
            if (isFadingIn)
            {
                fadeVolume += 0.05f;
                if (fadeVolume >= 1.0f)
                {
                    fadeVolume = 1.0f;
                    isFadingIn = false;
                }
                if (wavePlayer != null)
                {
                    wavePlayer.Volume = fadeVolume * currentVolume;
                }
            }
            else
            {
                fadeVolume -= 0.05f;
                if (fadeVolume <= 0.0f)
                {
                    fadeVolume = 0.0f;
                    fadeTimer.Stop();
                }
                if (wavePlayer != null)
                {
                    wavePlayer.Volume = fadeVolume * currentVolume;
                }
            }
        }

        private void ButtonPlay_Click(object sender, EventArgs e)
        {
            if (listBoxSongs.SelectedItem != null)
            {
                string selectedSong = listBoxSongs.SelectedItem.ToString();
                string songPath = Path.Combine(musicDirectory, selectedSong);
                PlaySong(songPath);
            }
        }

        private void ButtonPause_Click(object sender, EventArgs e)
        {
            PauseSong();
        }

        private void ButtonStop_Click(object sender, EventArgs e)
        {
            StopSong();
        }

        private void ButtonSettings_Click(object sender, EventArgs e)
        {
            Panel settingsPanel = Controls.OfType<Panel>().FirstOrDefault();
            if (settingsPanel != null)
            {
                settingsPanel.Visible = !settingsPanel.Visible;
            }
        }

        private void ButtonApplySettings_Click(object sender, EventArgs e)
        {
            if (checkBoxFullScreen.Checked)
            {
                this.WindowState = FormWindowState.Maximized;
                this.FormBorderStyle = FormBorderStyle.None;
                isFullScreen = true;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
                this.FormBorderStyle = FormBorderStyle.Sizable;
                isFullScreen = false;
            }
        }

        private void ButtonRevertSettings_Click(object sender, EventArgs e)
        {
            checkBoxFullScreen.Checked = isFullScreen;
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}

